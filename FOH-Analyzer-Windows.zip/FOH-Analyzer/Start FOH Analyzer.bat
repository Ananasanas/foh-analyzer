@echo off
rem Opens FOH Analyzer in Chrome if installed, otherwise Microsoft Edge.
set "APP=%~dp0FOH-Analyzer.html"
set "CHROME=%ProgramFiles%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe"
if not exist "%CHROME%" set "CHROME=%LocalAppData%\Google\Chrome\Application\chrome.exe"
if exist "%CHROME%" (
  start "" "%CHROME%" "%APP%"
) else (
  start "" msedge "%APP%"
)
